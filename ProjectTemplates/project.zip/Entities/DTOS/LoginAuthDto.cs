﻿namespace $safeprojectname$.Dtos
{
    public class LoginAuthDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
