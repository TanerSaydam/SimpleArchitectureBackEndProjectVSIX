﻿namespace $safeprojectname$.Concrete
{
    public class OperationClaim
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
