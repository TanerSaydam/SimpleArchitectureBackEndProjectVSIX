﻿using Core.$safeprojectname$;
using Entities.Concrete;

namespace $safeprojectname$.Repositories.UserOperationClaimRepository
{
    public interface IUserOperationClaimDal : IEntityRepository<UserOperationClaim>
    {
    }
}
