﻿namespace $safeprojectname$.Repositories.OperationClaimRepository.Constans
{
    public class OperationClaimMessages
    {
        public static string Added = "Yetki başarıyla oluşturuldu";
        public static string Updated = "Yetki başarıyla güncellendi";
        public static string Deleted = "Yetki başarıyla silindi";
        public static string NameIsNotAvaible = "Bu yetki adı daha önce kullanılmış";
    }
}
