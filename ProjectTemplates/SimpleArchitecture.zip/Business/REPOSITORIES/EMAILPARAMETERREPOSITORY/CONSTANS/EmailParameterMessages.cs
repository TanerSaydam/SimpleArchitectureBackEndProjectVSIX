﻿namespace $safeprojectname$.Repositories.EmailParameterRepository.Constans
{
    public class EmailParameterMessages
    {
        public static string AddedEmailParameter = "Mail parametesi başarıyla oluşturuldu";
        public static string UpdatedEmailParameter = "Mail parametesi başarıyla Güncellendi";
        public static string DeletedEmailParameter = "Mail parametesi başarıyla Silindi";
        public static string EmailSendSuccesiful = "Mail başarıyla gönderildi";
    }
}
