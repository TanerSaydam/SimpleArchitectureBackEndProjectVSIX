﻿using Castle.DynamicProxy;
using $safeprojectname$.CorssCuttingConcerns.Caching;
using $safeprojectname$.Utilities.Interceptors;
using $safeprojectname$.Utilities.IoC;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Aspects.Caching
{
    public class RemoveCacheAspect : MethodInterception
    {
        private string _pattern;
        private ICacheManager _cacheManager;

        public RemoveCacheAspect(string pattern)
        {
            _pattern = pattern;
            _cacheManager = ServiceTool.ServiceProvider.GetService<ICacheManager>();
        }

        protected override void OnSuccess(IInvocation invocation)
        {
            _cacheManager.RemoveByPattern(_pattern);
        }
    }
}
