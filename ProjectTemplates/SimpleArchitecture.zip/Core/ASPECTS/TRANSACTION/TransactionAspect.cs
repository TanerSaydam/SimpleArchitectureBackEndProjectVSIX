﻿using Castle.DynamicProxy;
using $safeprojectname$.Utilities.Interceptors;
using System.Transactions;

namespace $safeprojectname$.Aspects.Transaction
{
    public class TransactionAspect : MethodInterception
    {
        public override void Intercept(IInvocation invocation)
        {
            //async metotlarda bu aspect çalışmıyor. 
            invocation.Proceed();

            //using (TransactionScope transaction = new TransactionScope())
            //{
            //    try
            //    {
            //        invocation.Proceed();
            //        transaction.Complete();
            //    }
            //    catch (Exception)
            //    {
            //        transaction.Dispose();
            //        throw;
            //    }
            //}
        }
    }
}
