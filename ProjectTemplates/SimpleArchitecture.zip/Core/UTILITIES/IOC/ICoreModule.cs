﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Utilities.IoC
{
    public interface ICoreModule
    {
        void Load(IServiceCollection services);
    }
}
