﻿using Entities.Concrete;

namespace $safeprojectname$.Utilities.Security.JWT
{
    public interface ITokenHandler
    {
        Token CreateToken(User user, List<OperationClaim> operationClaims);
    }
}
