﻿using Core.$safeprojectname$;
using Entities.Concrete;

namespace $safeprojectname$.Repositories.UserRepository
{
    public interface IUserDal : IEntityRepository<User>
    {
        Task<List<OperationClaim>> GetUserOperatinonClaims(int userId);
    }
}
