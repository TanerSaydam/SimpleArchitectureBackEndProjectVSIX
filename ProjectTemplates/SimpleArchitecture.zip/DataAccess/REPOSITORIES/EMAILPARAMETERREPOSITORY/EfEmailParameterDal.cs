﻿using Core.$safeprojectname$.EntityFramework;
using $safeprojectname$.Context.EntityFramework;
using Entities.Concrete;

namespace $safeprojectname$.Repositories.EmailParameterRepository
{
    public class EfEmailParameterDal : EfEntityRepositoryBase<EmailParameter, SimpleContextDb>, IEmailParameterDal
    {
    }
}
