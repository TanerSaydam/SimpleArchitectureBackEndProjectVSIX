﻿using Core.$safeprojectname$;
using Entities.Concrete;

namespace $safeprojectname$.Repositories.EmailParameterRepository
{
    public interface IEmailParameterDal : IEntityRepository<EmailParameter>
    {

    }
}
