﻿using Core.$safeprojectname$;
using Entities.Concrete;

namespace $safeprojectname$.Repositories.OperationClaimRepository
{
    public interface IOperationClaimDal : IEntityRepository<OperationClaim>
    {

    }
}
