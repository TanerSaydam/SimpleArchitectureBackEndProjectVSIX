﻿using Core.$safeprojectname$.EntityFramework;
using $safeprojectname$.Context.EntityFramework;
using Entities.Concrete;

namespace $safeprojectname$.Repositories.OperationClaimRepository
{
    public class EfOperationClaimDal : EfEntityRepositoryBase<OperationClaim, SimpleContextDb>, IOperationClaimDal
    {

    }
}
