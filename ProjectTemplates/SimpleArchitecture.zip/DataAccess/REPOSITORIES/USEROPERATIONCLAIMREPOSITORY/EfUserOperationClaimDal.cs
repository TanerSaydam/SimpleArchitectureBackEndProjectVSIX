﻿using Core.$safeprojectname$.EntityFramework;
using $safeprojectname$.Context.EntityFramework;
using Entities.Concrete;

namespace $safeprojectname$.Repositories.UserOperationClaimRepository
{
    public class EfUserOperationClaimDal : EfEntityRepositoryBase<UserOperationClaim, SimpleContextDb>, IUserOperationClaimDal
    {
    }
}
